import React from "react";

const Form = () => {

    function sendMessage(){
        // Code 
    };

    return (
        <form className="contacts__form" onSubmit={sendMessage()}>
            <ul>
                <li>
                    <input type='text' name='name' placeholder="Name"/>
                    <input type='text' name='email' placeholder="Email"/>
                </li>
                <li>
                    <textarea rows="8" type="textarea" placeholder="Message" ></textarea>
                </li>
                <li>
                    <button contacts__form_btn>Send Message</button>
                </li>
            </ul>              
        </form>
    );
};


export default Form;