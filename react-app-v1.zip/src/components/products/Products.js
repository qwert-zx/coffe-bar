import React from "react";
import { useContext, useEffect, useState } from "react";
import { MainContext } from "../Main";


const Products = () => {

    console.log(useContext(MainContext))
	/* const [library, setLibrary] = useState([]); */
	const library = useContext(MainContext).products 
	
	const {getStorage} = useContext(MainContext);


	if (library.length === 0){
		getStorage()
	};

    function print(){	
		return library.map((item, index) => {
			return (
				<div key={index} className="tovar">
					<div className="foto">
						<span className="bludo">{item.name}</span>
						<span className="price">{item.price}</span>
					</div>
				</div>
			);
		});
	}
    return (
        <div className="home__menu_bottom">{print()}</div>
    );
};


export default Products;