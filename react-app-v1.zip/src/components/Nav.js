import React from "react";
import { Link } from "react-router-dom";

function Nav() {
	return (
		<nav className="nav">
            <ul>
                <li><Link to="/">Home</Link></li>
                <li><Link to="/menu/">Menu</Link></li>
                <li><Link to="/about/">About Us</Link></li>
                <li><Link to="/story/">Our Story</Link></li>
                <li><Link to="/blog/">Blog</Link></li>
                <li><Link to="/contacts/">Contacts</Link></li>
            </ul>
        </nav>
	);
}

export default Nav;