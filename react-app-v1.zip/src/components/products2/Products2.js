import React, { useState, useEffect } from "react";

const Products2 = () => {  

    const menuProduct = [{id: 1, name: 'Chicken Burger', price: 6.25, categories:'fastfood'},
                        {id: 2, name: 'Drp Cofee', price: 2.85, categories:'coffe'},
                        {id: 3, name: 'Coka Cola', price: 1.58,	categories:'coctails'},
                        {id: 4, name: 'Choco Cup Cake', price: 4.85, categories:'cake'},
                        {id: 5, name: 'Chowmin Noodle', price: 8.85, categories:'snacks'},
                        {id: 6, name: 'Fruit Salad', price: 3.97, categories:'snacks'},
                        {id: 7, name: 'Quafe Brade', price: 7.85, categories:'cake'},
                        {id: 8, name: 'Cocktail', price: 8.85, categories:'coctails'},
                        {id: 9, name: 'Dalgona Cofee', price: 4.97, categories:'coffe'},
                        {id: 10, name: 'French Fries', price: 7.85, categories:'fastfood'}];

    const [sortedArr, setSortedArr] = useState(menuProduct);


    function filterProduct(categories){
        if(categories === "all"){
            setSortedArr(menuProduct)
        } else {
            let newProductArr = [...menuProduct].filter(item => item.categories === categories)
            setSortedArr(newProductArr)
        }
    };

    function print(){	
		return sortedArr.map((item, index) => {
			return (
				<div key={index} className={item.categories}>
                    <div className={'img_' + item.id}></div>
					<div className="dish">
						<span>{item.name}</span>
						<span>$ {item.price}</span>
					</div>
				</div>
			);
		});
	}
    return (
        <>
        <div className="menu__sort">
        <ul>
            <li><a onClick={ () => filterProduct('all') }>All</a></li>
            <li><a onClick={ () => filterProduct('fastfood') }>Fast Food</a></li>
            <li><a onClick={ () => filterProduct('coffe') }>Cofee</a></li>
            <li><a onClick={ () => filterProduct('coctails') }>Coctails</a></li>
            <li><a onClick={ () => filterProduct('cake') }>Quafe Cake</a></li>
            <li><a onClick={ () => filterProduct('snacks') }>Snacks</a></li>
        </ul>
        </div>
        <div className="home__menu_bottom">{print()}</div>
        </>
    );
};


export default Products2;