import React, { useState, useEffect } from "react";
import { Routes, Route } from "react-router-dom";

import Home from './pages/Home';
import Menu from './pages/Menu';
import About from './pages/About';
import Story from './pages/Story';
import Blog from "./pages/Blog";
import Contacts from "./pages/Contacts";

export const MainContext = React.createContext();

function Main() {

	/* const options = {
		method: 'GET',
		headers: {
			'X-RapidAPI-Key': 'd9d71a2307msh6e765785f58599bp1fb9d1jsn3ed07306dfc3',
			'X-RapidAPI-Host': 'menu-restaurnt.p.rapidapi.com'
		}
	};
	const [error, setError] = useState(null);
	const [isLoaded, setIsLoaded] = useState(false);
	const [items, setItems] = useState([]);
	const [library, setLibrary] = useState([]);

	const products = items.menu

	useEffect(() => {
		fetch('https://menu-restaurnt.p.rapidapi.com/', options)
		  .then(res => res.json())
		  .then(
			(result) => {
			  setIsLoaded(true);
			  setItems(result);
			},
			(error) => {
			  setIsLoaded(true);
			  setError(error);
			}
		  )
	}, [])

	useEffect(() => {
		setStorage();
	}, []);

	useEffect(() => {
		if (!library || library.length === 0)  {
			const libraryLocal = getStorage();

			if (libraryLocal && libraryLocal.length > 0) {
				setLibrary([...libraryLocal]);
			}
		} else {
			setStorage();
		}

		// eslint-disable-next-line react-hooks/exhaustive-deps		
	}, [library]);

	function setStorage() {
		let itemsTmp = products;
		itemsTmp = JSON.stringify(itemsTmp);

		if (!itemsTmp) return;

		localStorage.setItem('items', itemsTmp);
	}

	function getStorage() {
		let libraryTmp = localStorage.getItem('items');
		if (!libraryTmp) return;
		libraryTmp = JSON.parse(libraryTmp);
		if (!libraryTmp) return;
		return libraryTmp;
	} */

	return (
		<main className="main">
		{/* <MainContext.Provider value={{products, getStorage}}> */}
		<Routes>
			<Route path="/" element={<Home />} />
			<Route path="/menu/" element={<Menu />} />
			<Route path="/about/" element={<About />} />
			<Route path="/Story/" element={<Story />} />
			<Route path="/blog/" element={<Blog />} />
			<Route path="/contacts/" element={<Contacts />} />
		</Routes>
		{/* </MainContext.Provider> */}
		</main>
	);
}

export default Main;