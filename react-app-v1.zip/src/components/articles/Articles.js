import React, { useState, useEffect } from "react";
import Modal from "../modal/Modal";

function Articles() {
    const [error, setError] = useState(null);
    const [isLoaded, setIsLoaded] = useState(false);
    const [items, setItems] = useState([]);
    const [modalActive, setModalActive] = useState(false);
  
    // Примечание: пустой массив зависимостей [] означает, что
    // этот useEffect будет запущен один раз
    // аналогично componentDidMount()
    useEffect(() => {
      fetch("http://jsonplaceholder.typicode.com/posts?_page=1&_limit=4")
        .then(res => res.json())
        .then(
          (result) => {
            setIsLoaded(true);
            setItems(result);
          },
          // Примечание: важно обрабатывать ошибки именно здесь, а не в блоке catch(),
          // чтобы не перехватывать исключения из ошибок в самих компонентах.
          (error) => {
            setIsLoaded(true);
            setError(error);
          }
        )
    }, [])

    console.log(items)


    if (error) {
      return <div>Ошибка: {error.message}</div>;
    } else if (!isLoaded) {
      return <div>Загрузка...</div>;
    } else {
      return (
        <>
        <ul>
            {items.map(item => (
            <li key={item.id}>
                <div className={"img_" + item.id}></div>
                <div className="blog__article_autor">
                    <div className="autor__wrapper">
                        <div id={'autor' + item.userId}></div>
                        <div>Andrew Jonson</div>
                    </div>
                    <div className="article__wrapper">
                        <span className="blog__article_title">{item.title}</span>
                        <a onClick={() => setModalActive(true)}>Read More</a>
                    </div>

                    <Modal active={modalActive} setActive={setModalActive}>
                        <span className="blog__article_title">{item.title}</span>
                        <span className="blog__article_title">{item.body}</span>
                    </Modal>

                </div>
            </li>))}
        </ul>
        </>
      );
    }
  }


export default Articles;